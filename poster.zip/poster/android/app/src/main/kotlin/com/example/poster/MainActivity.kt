package com.example.poster

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
